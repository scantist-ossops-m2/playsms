<?php
$plugin_config['id_ID']['title'] = 'Indonesian (Indonesia)';
