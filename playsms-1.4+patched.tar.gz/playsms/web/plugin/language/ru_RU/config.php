<?php
$plugin_config['ru_RU']['title'] = 'Russian (Russia)';
