<?php
$plugin_config['nb_NO']['title'] = 'Norwegian Bokmål (Norway)';
