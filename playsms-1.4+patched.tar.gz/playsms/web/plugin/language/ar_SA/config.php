<?php
$plugin_config['ar_SA']['title'] = 'Arabic (Saudi Arabia)';
