<?php
$plugin_config['pt_PT']['title'] = 'Portuguese (Portugal)';
