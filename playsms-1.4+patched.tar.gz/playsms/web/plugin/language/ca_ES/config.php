<?php
$plugin_config['ca_ES']['title'] = 'Catalan (Spain)';
