<?php
defined('_SECURE_') or die('Forbidden');

// plugin configuration
$plugin_config['site'] = array(
	'default_config' => array(
		'enable_register' => 0,
		'enable_forgot' => 1,
		'enable_logo' => 0,
		'logo_replace_title' => 0,
		'logo_url' => '' 
	),
	'site_config' => array() 
);
